#ifndef dplyr_EmptySubset_H
#define dplyr_EmptySubset_H

namespace dplyr {
    class EmptySubset{} ;
}
#endif
